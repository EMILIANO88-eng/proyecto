<?php
// Inicia la sesión para manejar variables de sesión como el usuario logueado
session_start();

// Redirige al usuario a una URL específica
function redirect($url) {
    header("Location: $url");
    exit();
}

// Verifica si un usuario está logueado
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Verifica si el usuario logueado es un administrador
function is_admin() {
    return isset($_SESSION['user_rol']) && $_SESSION['user_rol'] === 'admin';
}

// Protege una página para que solo usuarios logueados puedan acceder
function require_login() {
    if (!is_logged_in()) {
        redirect('login.php'); // Redirige a la página de login si no está logueado
    }
}

// Protege una página para que solo administradores puedan acceder
function require_admin() {
    if (!is_admin()) {
        redirect('index.php'); // O a una página de error/acceso denegado
    }
}

// Muestra mensajes flash (mensajes temporales para el usuario)
function set_message($message, $type = 'info') {
    $_SESSION['message'] = ['text' => $message, 'type' => $type];
}

function display_message() {
    if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        echo '<div class="alert alert-' . $message['type'] . ' alert-dismissible fade show" role="alert">';
        echo $message['text'];
        echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
        echo '</div>';
        unset($_SESSION['message']); // Elimina el mensaje después de mostrarlo
    }
}

?>