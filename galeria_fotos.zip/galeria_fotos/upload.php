<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_login(); // Solo usuarios logueados pueden subir fotos

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo = trim($_POST['titulo']);
    $descripcion = trim($_POST['descripcion']);
    
    // Directorio donde se guardarán las imágenes
    $target_dir = "uploads/";
    $uploadOk = 1;
    $message = '';
    
    // 1. Validar que se haya subido un archivo y que no haya errores
    if (!isset($_FILES["foto"]) || $_FILES["foto"]["error"] !== UPLOAD_ERR_OK) {
        $uploadOk = 0;
        $message = "Error al intentar subir el archivo. Código de error: " . $_FILES["foto"]["error"];
    } elseif (empty($titulo)) {
        $uploadOk = 0;
        $message = "El título de la foto es obligatorio.";
    } else {
        $target_file = $target_dir . basename($_FILES["foto"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Renombrar el archivo para evitar colisiones y añadir un ID único
        $new_file_name = uniqid('img_', true) . '.' . $imageFileType;
        $target_file = $target_dir . $new_file_name;

        // 2. Verificar si es una imagen real
        $check = getimagesize($_FILES["foto"]["tmp_name"]);
        if ($check === false) {
            $message = "El archivo no es una imagen válida.";
            $uploadOk = 0;
        }

        // 3. Verificar el tamaño del archivo (ej. max 5MB)
        if ($_FILES["foto"]["size"] > 500000000) {
            $message = "Lo siento, tu archivo es demasiado grande (máx. 5MB).";
            $uploadOk = 0;
        }

        // 4. Permitir ciertos formatos de archivo
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            $message = "Lo siento, solo se permiten archivos JPG, JPEG, PNG y GIF.";
            $uploadOk = 0;
        }
    }

    // 5. Verificar si $uploadOk es 0 por un error
    if ($uploadOk == 0) {
        set_message($message, 'danger');
    } else {
        // 6. Intentar mover el archivo subido
        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
            try {
                // 7. Insertar información de la foto en la base de datos
                $stmt = $pdo->prepare("INSERT INTO fotos (usuario_id, titulo, descripcion, ruta_archivo) VALUES (?, ?, ?, ?)");
                if ($stmt->execute([$user_id, $titulo, $descripcion, $target_file])) {
                    set_message("¡Foto subida exitosamente!", 'success');
                    redirect('dashboard.php'); // Redirigir al dashboard
                } else {
                    set_message("Error de base de datos al guardar la información de la foto.", 'danger');
                }
            } catch (PDOException $e) {
                set_message("Error de DB: " . $e->getMessage(), 'danger');
            }
        } else {
            set_message("Lo siento, hubo un error al mover el archivo subido. Revisa los permisos de la carpeta 'uploads'.", 'danger');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir Nueva Foto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="bg-light">
    <?php include 'includes/navbar.php'; ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <div class="card shadow-sm p-4">
                    <h2 class="card-title text-center mb-4 text-primary">Subir Nueva Foto 🖼️</h2>
                    <?php display_message(); ?>
                    
                    <form action="upload.php" method="post" enctype="multipart/form-data">
                        
                        <div class="mb-3">
                            <label for="titulo" class="form-label">Título de la Foto</label>
                            <input type="text" class="form-control" id="titulo" name="titulo" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="descripcion" class="form-label">Descripción (Opcional)</label>
                            <textarea class="form-control" id="descripcion" name="descripcion" rows="3"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="foto" class="form-label">Seleccionar Archivo de Imagen</label>
                            <input type="file" class="form-control" id="foto" name="foto" accept="image/*" required>
                            <small class="form-text text-muted">Formatos permitidos: JPG, JPEG, PNG, GIF. Máx. 5MB.</small>
                        </div>
                        
                        <div class="d-grid gap-2 mt-4">
                            <button type="submit" class="btn btn-primary btn-lg">Subir Foto</button>
                        </div>
                    </form>
                    
                    <p class="text-center mt-3">
                        <a href="dashboard.php" class="text-secondary">Volver al Dashboard</a>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>