<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_login(); 

$photo_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$user_id_logged_in = $_SESSION['user_id'];
$user_rol_logged_in = $_SESSION['user_rol'];
$redirect_to_admin = isset($_GET['redirect']) && $_GET['redirect'] === 'admin';

if ($photo_id > 0) {
    try {
        // 1. Obtener la información de la foto
        $stmt = $pdo->prepare("SELECT usuario_id, ruta_archivo FROM fotos WHERE id = ?");
        $stmt->execute([$photo_id]);
        $photo = $stmt->fetch();

        if ($photo) {
            // 2. Verificar Permisos: Propietario o Admin
            if ($photo['usuario_id'] == $user_id_logged_in || $user_rol_logged_in === 'admin') {
                
                // 3. Eliminar el archivo físico
                if (file_exists($photo['ruta_archivo'])) {
                    unlink($photo['ruta_archivo']); 
                }

                // 4. Eliminar el registro de la base de datos
                $stmt_delete = $pdo->prepare("DELETE FROM fotos WHERE id = ?");
                $stmt_delete->execute([$photo_id]);

                set_message("Foto eliminada exitosamente.", 'success');

            } else {
                set_message("No tienes permisos para eliminar esta foto.", 'danger');
            }
        } else {
            set_message("La foto no fue encontrada.", 'danger');
        }
    } catch (PDOException $e) {
        set_message("Error al eliminar la foto: " . $e->getMessage(), 'danger');
    }
} else {
    set_message("ID de foto no especificado.", 'danger');
}

// 5. Redireccionar
if ($redirect_to_admin) {
    // Redirige al administrador
    redirect('admin/index.php');
} else {
    // Redirige al usuario
    redirect('dashboard.php');
}
?>