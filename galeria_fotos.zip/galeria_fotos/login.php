<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (is_logged_in()) {
    if (is_admin()) {
        redirect('admin/index.php');
    } else {
        redirect('dashboard.php');
    }
}

$message = '';
$message_type = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_o_email = trim($_POST['nombre_o_email']);
    $password = $_POST['password'];

    if (empty($nombre_o_email) || empty($password)) {
        $message = 'Todos los campos son obligatorios.';
        $message_type = 'danger';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE nombre_usuario = ? OR email = ?");
        $stmt->execute([$nombre_o_email, $nombre_o_email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Inicio de sesión exitoso
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['nombre_usuario'];
            $_SESSION['user_rol'] = $user['rol'];

            set_message('¡Bienvenido, ' . $user['nombre_usuario'] . '!', 'success');

            if ($user['rol'] === 'admin') {
                redirect('admin/index.php');
            } else {
                redirect('dashboard.php');
            }
        } else {
            $message = 'Nombre de usuario/email o contraseña incorrectos.';
            $message_type = 'danger';
        }
    }
    set_message($message, $message_type);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Galería de Fotos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css"> </head>
<body class="bg-light">
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow-sm p-4">
                    <h2 class="card-title text-center mb-4">Iniciar Sesión</h2>
                    <?php display_message(); ?>
                    <form action="login.php" method="post">
                        <div class="mb-3">
                            <label for="nombre_o_email" class="form-label">Nombre de Usuario o Email</label>
                            <input type="text" class="form-control" id="nombre_o_email" name="nombre_o_email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Contraseña</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">Iniciar Sesión</button>
                        </div>
                    </form>
                    <p class="text-center mt-3">
                        ¿No tienes una cuenta? <a href="register.php">Registrarse</a>
                    </p>
                    <p class="text-center mt-2">
                        <a href="index.php">Volver a Inicio</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>