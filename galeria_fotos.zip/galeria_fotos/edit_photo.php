<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_login(); // Solo usuarios logueados pueden editar fotos

$user_id = $_SESSION['user_id'];
$photo_id = isset($_GET['id']) ? (int)$_GET['id'] : 0; // Obtener el ID de la foto de la URL

$photo = null;
$message = '';
$message_type = '';

// 1. Cargar los datos de la foto existente
if ($photo_id > 0) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM fotos WHERE id = ? AND usuario_id = ?");
        $stmt->execute([$photo_id, $user_id]);
        $photo = $stmt->fetch();

        if (!$photo) {
            set_message("Foto no encontrada o no tienes permisos para editarla.", 'danger');
            redirect('dashboard.php');
        }
    } catch (PDOException $e) {
        set_message("Error al cargar la foto: " . $e->getMessage(), 'danger');
        redirect('dashboard.php');
    }
} else {
    set_message("ID de foto no especificado.", 'danger');
    redirect('dashboard.php');
}

// 2. Procesar el formulario de edición cuando se envía
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_titulo = trim($_POST['titulo']);
    $new_descripcion = trim($_POST['descripcion']);

    if (empty($new_titulo)) {
        set_message("El título de la foto es obligatorio.", 'danger');
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE fotos SET titulo = ?, descripcion = ? WHERE id = ? AND usuario_id = ?");
            if ($stmt->execute([$new_titulo, $new_descripcion, $photo_id, $user_id])) {
                set_message("¡Foto actualizada exitosamente!", 'success');
                redirect('dashboard.php'); // Redirigir al dashboard después de la edición
            } else {
                set_message("No se pudo actualizar la foto. Inténtalo de nuevo.", 'danger');
            }
        } catch (PDOException $e) {
            set_message("Error de base de datos al actualizar la foto: " . $e->getMessage(), 'danger');
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Foto - Galería</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="bg-light">
    <?php include 'includes/navbar.php'; ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <div class="card shadow-sm p-4">
                    <h2 class="card-title text-center mb-4 text-info">Editar Foto 📝</h2>
                    <?php display_message(); ?>
                    
                    <?php if ($photo): // Mostrar el formulario solo si la foto existe y se cargó correctamente ?>
                        <form action="edit_photo.php?id=<?php echo $photo_id; ?>" method="post">
                            
                            <div class="mb-3">
                                <label for="titulo" class="form-label">Título de la Foto</label>
                                <input type="text" class="form-control" id="titulo" name="titulo" value="<?php echo htmlspecialchars($photo['titulo']); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="descripcion" class="form-label">Descripción (Opcional)</label>
                                <textarea class="form-control" id="descripcion" name="descripcion" rows="3"><?php echo htmlspecialchars($photo['descripcion']); ?></textarea>
                            </div>
                            
                            <div class="text-center mb-4">
                                <img src="<?php echo htmlspecialchars($photo['ruta_archivo']); ?>" class="img-fluid rounded" alt="Miniatura de la foto" style="max-height: 200px; object-fit: cover;">
                                <small class="d-block text-muted mt-2">No se puede cambiar el archivo de imagen aquí. Elimina y sube una nueva si deseas cambiar la imagen.</small>
                            </div>

                            <div class="d-grid gap-2 mt-4">
                                <button type="submit" class="btn btn-info btn-lg">Guardar Cambios</button>
                            </div>
                        </form>
                    <?php endif; ?>
                    
                    <p class="text-center mt-3">
                        <a href="dashboard.php" class="text-secondary">Volver al Dashboard</a>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>