<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
require_login(); // Solo usuarios logueados pueden acceder

$user_id = $_SESSION['user_id'];
$photos = [];

try {
    // Obtener fotos del usuario actual
    $stmt = $pdo->prepare("SELECT * FROM fotos WHERE usuario_id = ? ORDER BY fecha_subida DESC");
    $stmt->execute([$user_id]);
    $photos = $stmt->fetchAll();
} catch (PDOException $e) {
    set_message("Error al cargar las fotos: " . $e->getMessage(), 'danger');
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard de Usuario - Galería de Fotos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="bg-light">
    <?php include 'includes/navbar.php'; ?>

    <div class="container user-dashboard my-4">
        <h2 class="mb-4">Mis Fotos</h2>
        <?php display_message(); ?>

        <?php if (empty($photos)): ?>
            <div class="alert alert-info text-center" role="alert">
                Aún no has subido ninguna foto. ¡Anímate a <a href="upload.php">subir tu primera foto</a>!
            </div>
        <?php else: ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php foreach ($photos as $photo): ?>
                    <div class="col">
                        <div class="card h-100">
                            <img src="<?php echo htmlspecialchars($photo['ruta_archivo']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($photo['titulo']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($photo['titulo']); ?></h5>
                                <p class="card-text text-muted"><?php echo htmlspecialchars($photo['descripcion']); ?></p>
                                <p class="card-text"><small class="text-muted">Subida: <?php echo date("d/m/Y H:i", strtotime($photo['fecha_subida'])); ?></small></p>
                                <a href="edit_photo.php?id=<?php echo $photo['id']; ?>" class="btn btn-info btn-sm me-2">Editar</a>
                                <a href="delete_photo.php?id=<?php echo $photo['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que quieres eliminar esta foto?');">Eliminar</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>