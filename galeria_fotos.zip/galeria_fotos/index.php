<?php
require_once 'includes/functions.php';

if (is_logged_in()) {
    if (is_admin()) {
        redirect('admin/index.php'); // Redirige a la admin dashboard
    } else {
        redirect('dashboard.php'); // Redirige a la user dashboard
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido a la Galería de Fotos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .welcome-card {
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
            text-align: center;
        }
        .welcome-card h1 {
            color: #007bff;
            margin-bottom: 20px;
        }
        .welcome-card p {
            font-size: 1.1em;
            color: #555;
        }
        .btn-group {
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="welcome-card">
                    <h1>Bienvenido a Tu Galería de Fotos Personal</h1>
                    <p>
                        Crea una cuenta para subir, organizar y compartir tus mejores momentos.
                    </p>
                    <div class="btn-group" role="group" aria-label="Navegación">
                        <a href="register.php" class="btn btn-primary btn-lg me-2">Registrarse</a>
                        <a href="login.php" class="btn btn-outline-secondary btn-lg">Iniciar Sesión</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>