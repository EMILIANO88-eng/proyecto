<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

// **GUARDIA DE SEGURIDAD:** Solo para administradores
require_login();
require_admin();

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];
    $current_admin_id = $_SESSION['user_id'];

    // 1. Evitar que un administrador se elimine a sí mismo accidentalmente
    if ($user_id == $current_admin_id) {
        set_message("No puedes eliminar tu propia cuenta de administrador desde aquí.", 'warning');
        redirect('index.php');
    }

    try {
        // 2. Usar una transacción para asegurar la integridad de los datos
        $pdo->beginTransaction();

        // **IMPORTANTE:** Gracias a la restricción `ON DELETE CASCADE` en la tabla `fotos`,
        // al eliminar el usuario, sus fotos asociadas se eliminan automáticamente.

        // 3. Eliminar el usuario
        $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->execute([$user_id]);

        $pdo->commit();
        set_message("Usuario (ID: $user_id) y todas sus fotos eliminados exitosamente.", 'success');
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        set_message("Error al eliminar el usuario: " . $e->getMessage(), 'danger');
    }
	
	// ... (Código PHP existente para eliminar la foto)

if ($stmt->rowCount() > 0) {
    set_message("Foto eliminada exitosamente.", 'success');
} else {
    set_message("Error al eliminar la foto o no tienes permisos.", 'danger');
}

// Lógica de redirección basada en quién eliminó la foto
if (isset($_GET['redirect']) && $_GET['redirect'] === 'admin') {
    // Si fue eliminado por el administrador, redirigir de vuelta al listado de fotos del usuario
    $user_id = $_SESSION['user_id']; // Asume que el admin quiere volver a la vista del usuario
    // Necesitas el ID del usuario cuya foto se eliminó. Podrías pasar el user_id también por GET.
    // Por simplicidad, volvamos a la lista de usuarios.
    redirect('admin/index.php');
} else {
    // Redirigir al dashboard normal del usuario
    redirect('dashboard.php');
}
} else {
    set_message("ID de usuario no especificado.", 'warning');
}

redirect('index.php');
?>