<?php
// Los '..' son necesarios para retroceder al directorio raíz del proyecto
require_once '../includes/db.php';
require_once '../includes/functions.php';

// **GUARDIA DE SEGURIDAD:** Asegura que solo los administradores accedan
require_login();
require_admin();

$users = [];
$error_message = '';

try {
    // 1. Obtener la lista de usuarios (excluyendo el hash de la contraseña por seguridad, aunque ya estamos en el panel admin)
    // El orden por rol ayuda a ver quién es admin
    $stmt = $pdo->query("SELECT id, nombre_usuario, email, rol, fecha_registro FROM usuarios ORDER BY rol DESC, fecha_registro ASC");
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_message = "Error al cargar los usuarios: " . $e->getMessage();
    set_message($error_message, 'danger');
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración | Gestión de Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/styles.css">
    
</head>
<body class="admin-dashboard">
    <?php include 'includes/navbar_admin.php'; ?>

    <div class="container my-5">
        <div class="card shadow-lg">
            <div class="card-header">
                <h3 class="mb-0">Gestión de Usuarios Registrados</h3>
            </div>
            <div class="card-body">
                <?php display_message(); ?>
                
                <?php if (!empty($users)): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre de Usuario</th>
                                    <th>Email</th>
                                    <th>Rol</th>
                                    <th>Registrado el</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr class="<?php echo ($user['rol'] === 'admin') ? 'table-danger' : ''; ?>">
                                        <td><?php echo $user['id']; ?></td>
                                        <td><?php echo htmlspecialchars($user['nombre_usuario']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo ($user['rol'] === 'admin') ? 'danger' : 'success'; ?>">
                                                <?php echo ucfirst($user['rol']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date("d/m/Y", strtotime($user['fecha_registro'])); ?></td>
                                        <td>
                                            <a href="view_user_photos.php?user_id=<?php echo $user['id']; ?>" class="btn btn-sm btn-primary me-2" title="Ver Fotos">
                                                Fotos
                                            </a>
                                            <a href="delete_user.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('ATENCIÓN: ¿Estás seguro de que quieres ELIMINAR al usuario <?php echo htmlspecialchars($user['nombre_usuario']); ?>? Esto eliminará todas sus fotos.');" title="Eliminar Usuario">
                                                Eliminar
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-center text-muted">No hay usuarios registrados en la base de datos.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>