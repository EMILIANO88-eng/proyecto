<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

require_login();
require_admin();

$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : 0;
$user_name = '';
$photos = [];

try {
    // 1. Obtener el nombre de usuario para el título
    $stmt_user = $pdo->prepare("SELECT nombre_usuario FROM usuarios WHERE id = ?");
    $stmt_user->execute([$user_id]);
    $user = $stmt_user->fetch();

    if ($user) {
        $user_name = $user['nombre_usuario'];
        
        // 2. Obtener las fotos de ese usuario
        $stmt_photos = $pdo->prepare("SELECT * FROM fotos WHERE usuario_id = ? ORDER BY fecha_subida DESC");
        $stmt_photos->execute([$user_id]);
        $photos = $stmt_photos->fetchAll();
    } else {
        set_message("Usuario no encontrado.", 'danger');
        redirect('index.php');
    }
} catch (PDOException $e) {
    set_message("Error al cargar las fotos del usuario: " . $e->getMessage(), 'danger');
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Fotos de <?php echo htmlspecialchars($user_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body class="admin-dashboard">
    <?php include 'includes/navbar_admin.php'; ?>

    <div class="container my-4">
        <h2 class="mb-4">Fotos de: <span class="text-danger"><?php echo htmlspecialchars($user_name); ?></span></h2>
        <a href="index.php" class="btn btn-secondary mb-3"><< Volver a Usuarios</a>
        <?php display_message(); ?>

        <?php if (empty($photos)): ?>
            <div class="alert alert-warning text-center" role="alert">
                Este usuario aún no ha subido ninguna foto.
            </div>
        <?php else: ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php foreach ($photos as $photo): ?>
                    <div class="col">
                        <div class="card h-100 border-danger">
                            <img src="../<?php echo htmlspecialchars($photo['ruta_archivo']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($photo['titulo']); ?>">
                            <div class="card-body">
                                <h5 class="card-title text-danger"><?php echo htmlspecialchars($photo['titulo']); ?></h5>
                                <p class="card-text text-muted"><?php echo htmlspecialchars($photo['descripcion']); ?></p>
                                <p class="card-text"><small class="text-muted">Subida: <?php echo date("d/m/Y H:i", strtotime($photo['fecha_subida'])); ?></small></p>
                                <a href="../delete_photo.php?id=<?php echo $photo['id']; ?>&redirect=admin" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar esta foto del usuario <?php echo htmlspecialchars($user_name); ?>?');">
                                    Eliminar Foto
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>