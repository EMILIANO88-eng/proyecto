<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$message = '';
$message_type = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_usuario = trim($_POST['nombre_usuario']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($nombre_usuario) || empty($email) || empty($password) || empty($confirm_password)) {
        $message = 'Todos los campos son obligatorios.';
        $message_type = 'danger';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Formato de email inválido.';
        $message_type = 'danger';
    } elseif ($password !== $confirm_password) {
        $message = 'Las contraseñas no coinciden.';
        $message_type = 'danger';
    } elseif (strlen($password) < 6) {
        $message = 'La contraseña debe tener al menos 6 caracteres.';
        $message_type = 'danger';
    } else {
        // Verificar si el nombre de usuario o email ya existen
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE nombre_usuario = ? OR email = ?");
        $stmt->execute([$nombre_usuario, $email]);
        if ($stmt->fetchColumn() > 0) {
            $message = 'El nombre de usuario o email ya está registrado.';
            $message_type = 'danger';
        } else {
            // Hashear la contraseña antes de guardarla
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insertar el nuevo usuario en la base de datos
            $stmt = $pdo->prepare("INSERT INTO usuarios (nombre_usuario, email, password) VALUES (?, ?, ?)");
            if ($stmt->execute([$nombre_usuario, $email, $hashed_password])) {
                set_message('¡Registro exitoso! Ya puedes iniciar sesión.', 'success');
                redirect('login.php');
            } else {
                $message = 'Error al registrar el usuario.';
                $message_type = 'danger';
            }
        }
    }
    set_message($message, $message_type);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario - Galería de Fotos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css"> </head>
<body class="bg-light">
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow-sm p-4">
                    <h2 class="card-title text-center mb-4">Registro</h2>
                    <?php display_message(); ?>
                    <form action="register.php" method="post">
                        <div class="mb-3">
                            <label for="nombre_usuario" class="form-label">Nombre de Usuario</label>
                            <input type="text" class="form-control" id="nombre_usuario" name="nombre_usuario" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Contraseña</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirmar Contraseña</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">Registrarse</button>
                        </div>
                    </form>
                    <p class="text-center mt-3">
                        ¿Ya tienes una cuenta? <a href="login.php">Iniciar Sesión</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>